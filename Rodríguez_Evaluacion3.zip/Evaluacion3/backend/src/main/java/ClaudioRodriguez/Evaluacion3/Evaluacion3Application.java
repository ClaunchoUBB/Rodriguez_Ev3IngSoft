package ClaudioRodriguez.Evaluacion3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Evaluacion3Application {

	public static void main(String[] args) {
		SpringApplication.run(Evaluacion3Application.class, args);
	}

}
