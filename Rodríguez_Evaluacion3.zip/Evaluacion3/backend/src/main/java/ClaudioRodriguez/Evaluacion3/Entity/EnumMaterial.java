package ClaudioRodriguez.Evaluacion3.Entity;

public enum EnumMaterial {
    MADERA,
    METAL,
    PLASTICO,
    VIDRIO
}
