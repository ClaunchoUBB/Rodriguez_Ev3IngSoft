package ClaudioRodriguez.Evaluacion3.Entity;

public enum EnumTamano {
    PEQUEÑO,
    MEDIANO,
    GRANDE

}
